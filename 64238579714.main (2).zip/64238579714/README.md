# 东南亚风情餐厅网站

这是一个东南亚风情餐厅的单页应用网站，展示泰国、缅甸和台湾美食，包含菜单展示、联系信息和管理员后台功能。

## 代码下载与安装

### 方法一：使用Git克隆（推荐）

如果您已安装Git，可以通过以下命令克隆整个项目：

```bash
git clone https://github.com/your-username/southeast-asian-restaurant.git
cd southeast-asian-restaurant
```

### 方法二：下载ZIP文件

1. 访问项目仓库页面
2. 点击绿色的"Code"按钮
3. 选择"Download ZIP"
4. 将下载的ZIP文件解压到您的电脑上
5. 通过终端进入解压后的文件夹

### 安装依赖

项目使用pnpm作为包管理器，请确保您已安装Node.js和pnpm：

```bash
# 安装依赖
pnpm install

# 启动开发服务器
pnpm dev

# 构建生产版本
pnpm build
```

## 项目结构

- `src/components` - 可复用UI组件
- `src/pages` - 页面组件
- `src/lib` - 工具函数和数据
- `src/contexts` - React上下文

## 管理员功能

默认管理员凭据：
- 用户名: admin
- 密码: admin123

登录后可访问 `/admin` 页面管理菜单和查看订单。

## 部署

项目已配置GitHub Pages部署功能：

```bash
# 构建并部署到GitHub Pages
pnpm deploy
```

部署前请确保修改`package.json`中的`homepage`字段为您的仓库地址。