import Hero from "@/components/Hero";

export default function Home() {
  return (
    <div>
      <Hero />
      
      {/* 关于我们 */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">关于东南亚风情</h2>
              <p className="text-gray-600 mb-4">
                东南亚风情餐厅成立于2010年，致力于为顾客带来正宗的泰国、缅甸和台湾美食体验。我们的厨师团队来自东南亚各地，拥有丰富的烹饪经验。
              </p>
              <p className="text-gray-600 mb-6">
                我们坚持使用新鲜的食材和传统的烹饪方法，让每一位顾客都能品尝到地道的东南亚风味。无论您是想体验辛辣的泰国咖喱，还是想品尝温和的台湾小吃，我们都能满足您的需求。
              </p>
              <a 
                href="/menu" 
                className="inline-flex items-center text-amber-600 font-medium hover:text-amber-700"
              >
                探索我们的菜单
                <i className="fa-solid fa-arrow-right ml-2"></i>
              </a>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Thai%20cuisine%20plate%20presentation%20colorful&sign=ba35f8002db78360320395429c1d48b5" 
                  alt="泰国料理" 
                  className="rounded-lg shadow-md w-full h-48 object-cover transform translate-y-8"
                />
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Taiwanese%20snacks%20street%20food%20delicious&sign=9f8fd2e5dc315ecbb08a3d13696d9011" 
                  alt="台湾小吃" 
                  className="rounded-lg shadow-md w-full h-48 object-cover"
                />
              </div>
              <div className="space-y-4">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Burmese%20food%20traditional%20dish%20authentic&sign=d30111625164010dce4894a6b51b89d4" 
                  alt="缅甸美食" 
                  className="rounded-lg shadow-md w-full h-48 object-cover"
                />
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Southeast%20Asian%20restaurant%20ambience%20dining%20experience&sign=a0da180158b8b8f208c64b7a7d460393" 
                  alt="餐厅环境" 
                  className="rounded-lg shadow-md w-full h-48 object-cover transform translate-y-8"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* 特色菜系 */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">我们的特色菜系</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              探索来自泰国、缅甸和台湾的正宗美食，每一道菜都由我们的专业厨师精心烹制
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* 泰国料理 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow group">
              <div className="h-48 overflow-hidden">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Thai%20cuisine%20assorted%20dishes%20colorful%20presentation&sign=b2cbaebc5cff645ad3f55205d8b77ff9" 
                  alt="泰国料理" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <div className="inline-block bg-amber-100 text-amber-800 text-sm font-medium px-3 py-1 rounded-full mb-4">
                  泰国料理
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">泰式风味</h3>
                <p className="text-gray-600 mb-4">
                  体验辛辣、酸甜的泰国美食，包括经典的冬阴功汤、绿咖喱和泰式炒河粉
                </p>
                <a 
                  href="/menu" 
                  className="inline-flex items-center text-amber-600 font-medium hover:text-amber-700"
                >
                  查看泰国菜品
                  <i className="fa-solid fa-arrow-right ml-2"></i>
                </a>
              </div>
            </div>
            
            {/* 缅甸料理 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow group">
              <div className="h-48 overflow-hidden">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Burmese%20cuisine%20traditional%20dishes%20authentic&sign=94569dc2125f2a8497502997c347caad" 
                  alt="缅甸料理" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <div className="inline-block bg-green-100 text-green-800 text-sm font-medium px-3 py-1 rounded-full mb-4">
                  缅甸料理
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">缅甸风味</h3>
                <p className="text-gray-600 mb-4">
                  品尝独特的缅甸美食，包括鱼汤米线、茶叶沙拉和缅甸咖喱面
                </p>
                <a 
                  href="/menu" 
                  className="inline-flex items-center text-green-600 font-medium hover:text-green-700"
                >
                  查看缅甸菜品
                  <i className="fa-solid fa-arrow-right ml-2"></i>
                </a>
              </div>
            </div>
            
            {/* 台湾料理 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow group">
              <div className="h-48 overflow-hidden">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Taiwanese%20cuisine%20street%20food%20delicious&sign=eb3df66b5c09883cfff2e61b56c5f3f7" 
                  alt="台湾料理" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <div className="inline-block bg-red-100 text-red-800 text-sm font-medium px-3 py-1 rounded-full mb-4">
                  台湾料理
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">台湾风味</h3>
                <p className="text-gray-600 mb-4">
                  享受地道的台湾小吃，包括卤肉饭、蚵仔煎和珍珠奶茶
                </p>
                <a 
                  href="/menu" 
                  className="inline-flex items-center text-red-600 font-medium hover:text-red-700"
                >
                  查看台湾菜品
                  <i className="fa-solid fa-arrow-right ml-2"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* 顾客评价 */}
      <section className="py-16 bg-amber-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">顾客的评价</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              听听我们的顾客怎么说
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="flex text-amber-400 mb-4">
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
              </div>
              <p className="text-gray-600 mb-6 italic">
                "这里的冬阴功汤是我在北京喝过最正宗的，味道和我在曼谷喝到的一样好！服务也很热情。"
              </p>
              <div className="flex items-center">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Customer%20avatar%20female%20smiling&sign=ffecdbdccd4c303ed7c5f2bffcbc690d" 
                  alt="顾客头像" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-800">李小姐</h4>
                  <p className="text-gray-500 text-sm">常客</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="flex text-amber-400 mb-4">
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star-half-stroke"></i>
              </div>
              <p className="text-gray-600 mb-6 italic">
                "作为一个来自台湾的人，我可以说这里的卤肉饭非常地道，让我想起了家乡的味道。"
              </p>
              <div className="flex items-center">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Customer%20avatar%20male%20smiling&sign=421a85ca95c262baae609ea78c60e0b4" 
                  alt="顾客头像" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-800">王先生</h4>
                  <p className="text-gray-500 text-sm">台湾顾客</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="flex text-amber-400 mb-4">
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
              </div>
              <p className="text-gray-600 mb-6 italic">
                "我和朋友一起来尝试了缅甸料理，味道非常独特，服务员还详细介绍了每道菜的由来，体验很棒！"
              </p>
              <div className="flex items-center">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Customer%20avatar%20female%20happy&sign=ae91bf8607582bbdc7fea06884fca3c6" 
                  alt="顾客头像" 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-800">张女士</h4>
                  <p className="text-gray-500 text-sm">第一次来访</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
         {/* 联系我们 CTA */}
         <section className="py-20 bg-gray-800 text-white">
           <div className="container mx-auto px-4 text-center">
             <h2 className="text-3xl md:text-4xl font-bold mb-4">准备好品尝东南亚美食了吗?</h2>
             <p className="text-gray-300 max-w-2xl mx-auto mb-8">
               来我们的餐厅享用正宗的泰国、缅甸和台湾美食，或通过电话预订您的座位
             </p>
             <div className="flex flex-col sm:flex-row justify-center gap-4">
               <a 
                 href="/contact" 
                 className="bg-amber-600 hover:bg-amber-700 text-white font-medium py-3 px-8 rounded-full transition-all transform hover:scale-105 shadow-lg"
               >
                 联系我们
               </a>
               <a 
                 href="tel:010-12345678" 
                 className="bg-transparent border-2 border-white hover:bg-white/10 text-white font-medium py-3 px-8 rounded-full transition-all"
               >
                 <i className="fa-solid fa-phone mr-2"></i> 立即预订
               </a>
             </div>
           </div>
         </section>
 
           {/* 网站访问状态 */}
           <div className="bg-gradient-to-b from-green-50 to-white border-t border-green-200 py-10 px-6">
             <div className="max-w-4xl mx-auto">
               <div className="bg-white rounded-2xl shadow-lg p-8 mb-8 border border-green-100">
                 <div className="flex items-center justify-center mb-6">
                   <div className="bg-green-100 p-3 rounded-full text-green-600 mr-3">
                     <i className="fa-solid fa-check-circle text-2xl"></i>
                   </div>
                   <h3 className="text-2xl font-bold text-gray-800">网站已准备就绪，可以访问！</h3>
                 </div>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                   <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                     <h4 className="text-lg font-semibold text-blue-800 mb-4 flex items-center">
                       <i className="fa-solid fa-laptop-code mr-2"></i>
                       本地开发访问
                     </h4>
                     <div className="space-y-4">
                       <div>
                         <p className="text-sm text-gray-600 mb-2">在终端运行以下命令:</p>
                         <code className="bg-white px-3 py-2 rounded-md text-blue-600 font-mono text-sm inline-block">pnpm dev</code>
                       </div>
                       <div>
                         <p className="text-sm text-gray-600 mb-2">然后在浏览器中访问:</p>
                         <a href="http://localhost:3000" className="bg-white px-3 py-2 rounded-md text-blue-600 font-medium inline-flex items-center hover:bg-blue-50 transition-colors">
                           <i className="fa-solid fa-link mr-2"></i>
                           http://localhost:3000
                         </a>
                       </div>
                     </div>
                   </div>
                   
                   <div className="bg-amber-50 p-6 rounded-xl border border-amber-100">
                     <h4 className="text-lg font-semibold text-amber-800 mb-4 flex items-center">
                       <i className="fa-solid fa-globe mr-2"></i>
                       线上部署访问
                     </h4>
                     <div className="space-y-4">
                       <div>
                         <p className="text-sm text-gray-600 mb-2">完成部署后访问:</p>
                         <p className="bg-white px-3 py-2 rounded-md text-amber-600 font-medium text-sm">
                           https://&lt;你的GitHub用户名&gt;.github.io/&lt;你的仓库名&gt;
                         </p>
                       </div>
                       <div>
                         <p className="text-xs text-gray-500 italic">
                           提示: 替换&lt;你的GitHub用户名&gt;和&lt;你的仓库名&gt;为实际信息后即可访问
                         </p>
                       </div>
                     </div>
                   </div>
                 </div>
                 
                 <div className="bg-gray-50 p-4 rounded-lg">
                   <h4 className="text-sm font-medium text-gray-800 mb-2 flex items-center">
                     <i className="fa-solid fa-info-circle text-gray-500 mr-2"></i>
                     管理员登录信息
                   </h4>
                    <p className="text-sm text-gray-700">
                      默认凭据: <code className="bg-white px-2 py-1 rounded text-amber-700 font-medium">admin/admin123</code>
                    </p>
                  </div>

                  {/* 部署错误排查 */}
                  <div className="mt-6 bg-red-50 border border-red-100 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-red-800 mb-2 flex items-center">
                      <i className="fa-solid fa-exclamation-circle text-red-500 mr-2"></i>
                      部署问题排查
                    </h4>
                    <ul className="text-sm text-red-700 space-y-2">
                      <li>确保已运行 <code className="bg-white px-1 py-0.5 rounded text-red-800">pnpm run deploy</code> 命令</li>
                      <li>检查GitHub仓库是否已正确配置Pages功能</li>
                      <li>访问GitHub仓库的"Settings &gt; Pages"部分确认部署状态</li>
                      <li>首次部署可能需要10-15分钟才能生效</li>
                    </ul>
                  </div>
               </div>
               
               <div className="text-center text-sm text-gray-500">
                 <p>如有访问问题，请检查部署配置或重新运行开发服务器</p>
               </div>
             </div>
           </div>
    </div>
  );
}