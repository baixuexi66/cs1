import { useEffect, useState } from 'react';
import MenuSection from '@/components/MenuSection';
import { getMenuData, MenuItem } from '@/lib/menuData';

export default function Menu() {
  const [menuItems, setMenuItems] = useState({
    thai: [] as MenuItem[],
    burmese: [] as MenuItem[],
    taiwanese: [] as MenuItem[]
  });

  useEffect(() => {
    // 从本地存储加载最新菜单数据
    const data = getMenuData();
    setMenuItems(data);
  }, []);

  return (
    <div>
      {/* 菜单头部 */}
      <section className="relative h-64 bg-gray-800 flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Southeast%20Asian%20food%20assorted%20dishes%20colorful%20presentation&sign=2f821bcb565b572b327634efd16627c2" 
            alt="东南亚美食" 
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl font-bold mb-2">我们的菜单</h1>
          <p className="text-xl opacity-90">探索正宗的泰国、缅甸和台湾美食</p>
        </div>
      </section>
      
      {/* 泰国料理 */}
      <MenuSection 
        title="泰国料理" 
        description="辛辣、酸甜的泰国风味，使用新鲜香草和香料" 
        items={menuItems.thai} 
        icon="fa-leaf" 
        color="bg-green-100 text-green-600"
      />
      
      {/* 缅甸料理 */}
      <MenuSection 
        title="缅甸料理" 
        description="独特的缅甸风味，结合了东南亚和南亚的烹饪特色" 
        items={menuItems.burmese} 
        icon="fa-pepper-hot" 
        color="bg-amber-100 text-amber-600"
      />
      
      {/* 台湾料理 */}
      <MenuSection 
        title="台湾料理" 
        description="地道的台湾小吃和家常菜，口味丰富多样" 
        items={menuItems.taiwanese} 
        icon="fa-utensils" 
        color="bg-red-100 text-red-600"
      />
      
      {/* 预订提示 */}
      <section className="py-16 bg-gray-50 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">想品尝这些美味佳肴吗？</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            立即预订您的座位，体验正宗的东南亚美食之旅
          </p>
          <a 
            href="/contact" 
            className="bg-amber-600 hover:bg-amber-700 text-white font-medium py-3 px-8 rounded-full transition-all transform hover:scale-105 shadow-md inline-block"
          >
            联系我们进行预订
          </a>
        </div>
      </section>
    </div>
  );
}