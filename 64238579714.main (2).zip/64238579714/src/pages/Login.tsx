import { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '@/contexts/authContext';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // 简单表单验证
    if (!username || !password) {
      toast.error('请输入用户名和密码');
      setIsLoading(false);
      return;
    }
    
    // 调用登录函数
    const success = login(username, password);
    
    if (success) {
      toast.success('登录成功，欢迎回来！');
      navigate('/admin');
    } else {
      toast.error('用户名或密码不正确');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            管理员登录
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            请输入管理员凭据以访问管理后台
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <input type="hidden" name="remember" value="true" />
          <div className="rounded-md -space-y-px">
            <div>
              <label htmlFor="username" className="sr-only">用户名</label>
              <input
                id="username"
                name="username"
                type="text"
                required
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 focus:z-10 sm:text-sm"
                placeholder="用户名"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="password" className="sr-only">密码</label>
              <input
                id="password"
                name="password"
                type="password"
                required
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-amber-500 focus:border-amber-500 focus:z-10 sm:text-sm"
                placeholder="密码"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className={cn(
                "group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500",
                isLoading ? "opacity-70 cursor-not-allowed" : ""
              )}
            >
              {isLoading ? (
                <span className="flex items-center">
                  <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                  登录中...
                </span>
              ) : (
                <span className="flex items-center">
                  <i className="fa-solid fa-lock mr-2"></i>
                  登录
                </span>
              )}
            </button>
          </div>
        </form>
        
         <div className="text-center text-sm text-gray-500 space-y-4">
            <p className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded">
               <i className="fa-solid fa-info-circle text-amber-500 mr-2"></i>
               管理员默认凭据: <span className="font-mono bg-white px-2 py-1 rounded shadow-sm">admin/admin123</span>
              </p>
              <p className="bg-blue-50 border-l-4 border-blue-500 p-3 rounded text-sm">
                <i className="fa-solid fa-info-circle text-blue-500 mr-2"></i>网站访问说明: 请先运行 <code className="bg-white px-1 py-0.5 rounded">pnpm dev</code> 启动开发服务器，然后在浏览器访问 <code className="bg-white px-1 py-0.5 rounded">http://localhost:3000</code>
              </p>
              <p className="bg-green-50 border-l-4 border-green-500 p-3 rounded text-sm">
                <i className="fa-solid fa-lightbulb text-green-500 mr-2"></i>如果您看到此页面，表示应用已成功加载。请使用上方凭据登录管理后台。
             </p>
         </div>
      </div>
    </div>
  );
}