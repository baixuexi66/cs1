import { Routes, Route, Navigate } from "react-router-dom";
import { ErrorBoundary } from "react-error-boundary";
import { toast } from "sonner";
import { useContext } from "react";
import Home from "@/pages/Home";
import Menu from "@/pages/Menu";
import Contact from "@/pages/Contact";
import Login from "@/pages/Login";
import AdminDashboard from "@/pages/AdminDashboard";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AIChatbot from "@/components/AIChatbot";
import { useLocation } from "react-router-dom";
import { AuthContext, useAuthProvider } from '@/contexts/authContext';

// 受保护的路由组件 - 仅允许已认证用户访问
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useContext(AuthContext);
  if (!isAuthenticated) {
    // 如果未认证，重定向到登录页
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

export default function App() {
  const location = useLocation();
  // 创建认证提供器
  const authProvider = useAuthProvider();
  return (
    <AuthContext.Provider value={authProvider}>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <ErrorBoundary
            fallback={
              <div className="flex flex-col items-center justify-center h-full p-6 text-center">
                <i className="fa-solid fa-exclamation-triangle text-5xl text-amber-500 mb-4"></i>
                <h2 className="text-2xl font-bold text-gray-800 mb-2">页面加载出错</h2>
                <p className="text-gray-600 mb-6">抱歉，页面加载时发生错误</p>
                <button 
                  onClick={() => window.location.reload()}
                  className="bg-amber-600 hover:bg-amber-700 text-white px-6 py-2 rounded-md transition-colors"
                >
                  刷新页面
                </button>
              </div>
            }
            onError={(error) => {
              console.error("应用错误:", error);
              toast.error("页面加载出错，请刷新重试");
            }}
          >
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/menu" element={<Menu />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/login" element={<Login />} />
              <Route 
                path="/admin" 
                element={
                  <ProtectedRoute>
                    <AdminDashboard />
                  </ProtectedRoute>
                } 
              />
            </Routes>
          </ErrorBoundary>
         </main>
        </div>
        <Footer />
        {/* 仅在非管理页面显示AI客服 */}
       {location.pathname !== '/admin' && <AIChatbot />}
    </AuthContext.Provider>
  );
}