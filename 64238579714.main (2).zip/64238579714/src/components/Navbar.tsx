import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useContext, useState } from 'react';
import { AuthContext } from '@/contexts/authContext';

interface NavbarProps {
  className?: string;
}

export default function Navbar({ className }: NavbarProps) {
  const authContext = useContext(AuthContext);
  const isAuthenticated = authContext.isAuthenticated;
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // 切换移动端菜单
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };
  
  return (
    <nav className={cn(
      "sticky top-0 z-50 bg-white/90 backdrop-blur-sm shadow-sm",
      className
    )}>
      <div className="container mx-auto px-4 py-[14px] flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-amber-600 flex items-center">
          <i className="fa-solid fa-utensils mr-2"></i>
          <span>东南亚风情</span>
        </Link>
        
        {/* 桌面端导航 */}
        <div className="hidden md:flex items-center space-x-8">
          <Link 
            to="/" 
            className="text-gray-700 hover:text-amber-600 transition-colors font-medium"
          >
            首页
          </Link>
          <Link 
            to="/menu" 
            className="text-gray-700 hover:text-amber-600 transition-colors font-medium"
          >
            菜单
          </Link>
          <Link 
            to="/contact" 
            className="text-gray-700 hover:text-amber-600 transition-colors font-medium"
          >
            联系方式
          </Link>
          
          {/* 管理员链接 - 仅当已认证时显示 */}
          {isAuthenticated ? (
            <Link 
              to="/admin" 
              className="text-amber-600 hover:text-amber-700 transition-colors font-medium flex items-center"
            >
              <i className="fa-solid fa-cog mr-1"></i>
              管理后台
            </Link>
          ) : (
            <Link 
              to="/login" 
              className="bg-amber-600 hover:bg-amber-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
            >
              <i className="fa-solid fa-user-circle mr-1"></i>
              管理员登录
            </Link>
          )}
        </div>
        
        {/* 移动端菜单按钮 */}
        <button 
          className="md:hidden text-gray-700"
          onClick={toggleMobileMenu}
          aria-label={mobileMenuOpen ? "关闭菜单" : "打开菜单"}
        >
          {mobileMenuOpen ? (
            <i className="fa-solid fa-times text-xl"></i>
          ) : (
            <i className="fa-solid fa-bars text-xl"></i>
          )}
        </button>
      </div>
      
      {/* 移动端导航菜单 */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 shadow-lg animate-in slide-in-from-top duration-300">
          <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
            <Link 
              to="/" 
              className="text-gray-700 hover:text-amber-600 transition-colors font-medium py-2 px-4 rounded-md hover:bg-gray-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              首页
            </Link>
            <Link 
              to="/menu" 
              className="text-gray-700 hover:text-amber-600 transition-colors font-medium py-2 px-4 rounded-md hover:bg-gray-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              菜单
            </Link>
            <Link 
              to="/contact" 
              className="text-gray-700 hover:text-amber-600 transition-colors font-medium py-2 px-4 rounded-md hover:bg-gray-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              联系方式
            </Link>
            
            {/* 管理员链接 - 仅当已认证时显示 */}
            {isAuthenticated ? (
              <Link 
                to="/admin" 
                className="text-amber-600 hover:text-amber-700 transition-colors font-medium py-2 px-4 rounded-md hover:bg-amber-50 flex items-center"
                onClick={() => setMobileMenuOpen(false)}
              >
                <i className="fa-solid fa-cog mr-1"></i>
                管理后台
              </Link>
            ) : (
              <Link 
                to="/login" 
                className="bg-amber-600 hover:bg-amber-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                <i className="fa-solid fa-user-circle mr-1"></i>
                管理员登录
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}