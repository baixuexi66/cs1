export default function ContactInfo() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-800 mb-6">联系我们</h2>
          
          <div className="bg-white p-8 rounded-xl shadow-md mb-8">
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-amber-100 p-3 rounded-full mr-4">
                  <i className="fa-solid fa-map-marker text-amber-600"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">地址</h3>
                  <p className="text-gray-600">北京市朝阳区建国路88号</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-amber-100 p-3 rounded-full mr-4">
                  <i className="fa-solid fa-phone text-amber-600"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">电话</h3>
                  <p className="text-gray-600">0905862449</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-amber-100 p-3 rounded-full mr-4">
                  <i className="fa-solid fa-envelope text-amber-600"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">邮箱</h3>
                  <p className="text-gray-600">decun172@gmail.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-amber-100 p-3 rounded-full mr-4">
                  <i className="fa-brands fa-weixin text-amber-600"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">微信</h3>
                  <p className="text-gray-600">Nobel172</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-amber-100 p-3 rounded-full mr-4">
                  <i className="fa-solid fa-clock text-amber-600"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">营业时间</h3>
                  <ul className="text-gray-600 space-y-1">
                    <li>周一至周五: 11:00 - 14:30, 17:00 - 22:00</li>
                    <li>周六至周日: 11:00 - 22:30</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          
           <div className="flex space-x-4">
             <a href="#" className="bg-gray-100 hover:bg-gray-200 p-3 rounded-full transition-colors cursor-not-allowed" title="部署后可配置">
               <i className="fa-brands fa-facebook text-gray-700"></i>
             </a>
             <a href="#" className="bg-gray-100 hover:bg-gray-200 p-3 rounded-full transition-colors cursor-not-allowed" title="部署后可配置">
               <i className="fa-brands fa-instagram text-gray-700"></i>
             </a>
             <a href="#" className="bg-gray-100 hover:bg-gray-200 p-3 rounded-full transition-colors cursor-not-allowed" title="部署后可配置">
               <i className="fa-brands fa-weixin text-gray-700"></i>
             </a>
           </div>
        </div>
        
        <div className="rounded-xl overflow-hidden shadow-lg h-96">
          {/* 地图图片占位 */}
          <img 
            src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Map%20location%20restaurant%20Beijing%20China%20aerial%20view&sign=2207ed509a14f530dc11a94373fb550a" 
            alt="餐厅位置地图" 
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </div>
  );
}