import { cn } from '@/lib/utils';

interface DishCardProps {
  image: string;
  name: string;
  description: string;
  price: string;
  className?: string;
  isSoldOut: boolean;
}

export default function DishCard({ 
  image, 
  name, 
  description, 
  price, 
  className,
  isSoldOut
}: DishCardProps) {
  return (
    <div className={cn(
      "bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative",
      className,
      isSoldOut ? "opacity-80" : ""
    )}>
      {/* 已售完标签 */}
      {isSoldOut && (
        <div className="absolute top-3 right-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-md z-10">
          已售完
        </div>
      )}

      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className={`text-lg font-bold ${isSoldOut ? 'text-gray-500 line-through' : 'text-gray-800'}`}>{name}</h3>
          <span className={`font-semibold ${isSoldOut ? 'text-gray-400' : 'text-amber-600'}`}>{price}</span>
        </div>
        <p className={`text-sm line-clamp-2 ${isSoldOut ? 'text-gray-400' : 'text-gray-600'}`}>{description}</p>
      </div>
    </div>
  );
}